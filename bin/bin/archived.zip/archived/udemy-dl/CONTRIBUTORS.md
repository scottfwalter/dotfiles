### List of contributors who made the contribution either in form of feature request or a bugfix
 - @jdsantiagojr (fixed UnicodeEncode error)
 - @kizbitz (fixed TypeError: write() argument must be str, not bytes)
 - @SalihKARAHAN (Added Turkish character support)
 - @Stekot (Remove windows reserved characters from the title)
 - @ghost (added pep8 on udemy-dl.py)
 - @serhattsnmz (added fix for password error, suggested some great features)
 - @Nocxy (Checked with the recent version of MAC oSx)
 - @tofanelli (gave support to many users and also suggested some features)
 - @NoMoreUsernamesAvailable (Feature request for Umlauts (unicode based characters) in filenames)
 - @RuthlessRuler (Requested to add support Aria2c downloader)
 - @alfari16 (Download from specific chapter)
 - @arsenico13 (fixed KeyError if a chapter has no lectures)
 - @FaisalUmair (Special thanks for a quick help & Guide) <3.
 - @pavelnazimok (Thanks for the quick patch)
 - @brundidge (Thanks for a quick bug fixes)

> Thanks to all other contributors if i missed any one.