from downloader import Downloader

cookie = """
PHPSESSID=3e59fe6c19061b1c3e1012b4fda352c9; show-like-copy=0; YII_CSRF_TOKEN=azJPdW9hZjU1YVFHZU5ZZmg4OUNWNDIyVlJzVUxUM1MYEmdXJXZ-fQCwNAh8epSoagc8HctzH8kYMGQoz-CqJQ%3D%3D; first_landing=utm_campaign%3Dteacher-referral%26utm_source%3DShortUrl%26utm_medium%3Dteacher-referral%26referrer%3Dhttps%3A%2F%2Fwww.youtube.com%2F%26referring_username%3D; ss-ref=%7B%22teacher%22%3A%7B%227364129%22%3A%7B%22classId%22%3A%22306237%22%2C%22referralType%22%3A%22teacher%22%7D%7D%7D; visitor_tracking=utm_campaign%3Dteacher-referral%26utm_source%3DShortUrl%26utm_medium%3Dteacher-referral%26referrer%3Dhttps%3A%2F%2Fwww.youtube.com%2F%26referring_username%3D; orientation-flow-data=%7B%22orientationPath%22%3A%7B%22orientation%5C%2Findex%22%3A%22orientation%5C%2Fcheckout%22%2C%22orientation%5C%2Fcheckout%22%3A%22orientation%5C%2Fcomplete%22%7D%2C%22viewedPages%22%3A%5B%5D%2C%22finalRedirect%22%3A%22https%3A%5C%2F%5C%2Fwww.skillshare.com%5C%2Fclasses%5C%2F1430253622%5C%2FsubscriptionEnroll%3Fclass-state%3Dmembership-only-one-click-enroll%22%2C%22completesOrientation%22%3Afalse%2C%22force%22%3Afalse%7D; IR_gbd=skillshare.com; G_ENABLED_IDPS=google; __ssid=0e667bf5a1369621126f84035fd34fd; IRMS_la4650=1552936084359; __stripe_sid=ddccbc93-dac8-4c78-be84-903c92025c0d; __stripe_mid=e47f5095-7966-402d-a366-ce0ef5f37fd1; ext_pgvwcount=0.9; hibext_instdsigdipv2=1; skillshare_user_=63131717fd380feb73eb1633fb55d7a14e62b127a%3A4%3A%7Bi%3A0%3Bs%3A7%3A%222956080%22%3Bi%3A1%3Bs%3A21%3A%22scott%40scottwalter.com%22%3Bi%3A2%3Bi%3A2592000%3Bi%3A3%3Ba%3A11%3A%7Bs%3A5%3A%22email%22%3Bs%3A21%3A%22scott%40scottwalter.com%22%3Bs%3A9%3A%22firstName%22%3Bs%3A5%3A%22Scott%22%3Bs%3A8%3A%22lastName%22%3Bs%3A6%3A%22Walter%22%3Bs%3A8%3A%22headline%22%3BN%3Bs%3A3%3A%22pic%22%3Bs%3A67%3A%22https%3A%2F%2Fstatic.skillshare.com%2Fassets%2Fimages%2Fdefault-profile-lrg.jpg%22%3Bs%3A5%3A%22picSm%22%3Bs%3A66%3A%22https%3A%2F%2Fstatic.skillshare.com%2Fassets%2Fimages%2Fdefault-profile-sm.jpg%22%3Bs%3A5%3A%22picLg%22%3Bs%3A67%3A%22https%3A%2F%2Fstatic.skillshare.com%2Fassets%2Fimages%2Fdefault-profile-lrg.jpg%22%3Bs%3A9%3A%22isTeacher%22%3Bs%3A1%3A%220%22%3Bs%3A8%3A%22username%22%3Bs%3A6%3A%22160110%22%3Bs%3A3%3A%22zip%22%3Bs%3A0%3A%22%22%3Bs%3A6%3A%22cityID%22%3Bs%3A1%3A%220%22%3B%7D%7D; ss-subscription-coupon=referral2m
"""

dl = Downloader(cookie=cookie)

# download by class URL:
dl.download_course_by_url('https://www.skillshare.com/classes/Learn-to-Use-the-Pen-Tool-in-Affinity-Designer/1044233822')

# or by class ID:
# dl.download_course_by_class_id(189505397)
