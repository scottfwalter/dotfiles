#! /bin/bash

bb_project="BA"

if [ "$1" ]
then
	bb_project="$1"
fi


echo -e "Welcome to the Clone Repos Tool\n"
echo "I will clone all the repos from the '$bb_project' Bitbucket project into your current directory, which is `pwd`"
echo -e "If you would like to clone the repos from another Bitbucket project simply pass it as a parameter to this tool.  For example `basename "$0"` wfo\n"

echo "Enter your Bitbucket Username:"
read username

echo "Enter your Bitbucket Password:"
# save original terminal setting.
stty_orig=`stty -g`
# turn-off echoing.
stty -echo
# read the password
read password
# restore terminal setting.
stty $stty_orig

repos=$(curl -u $username:$password http://tlvgit02.nice.com:7990/rest/api/1.0/projects/$bb_project/repos?limit=1000)
repos=$(echo $repos | sed 's:}:\\n:g')
repos=`echo -e $repos |  grep "http://" | grep -v "/browse" | grep "@" | sed 's/.*href"://' | sed 's/\"//g' | sed 's/,//g' | sed 's/name:http//g'`
repo_counter=0

for repo in $repos
do
    let repo_counter=repo_counter+1
	repo=`echo $repo | sed 's:/ba/:/uxa/:g'`
	dir_name=`echo $repo | sed 's@.*/@@' | sed 's/\.git//g'`

    echo ""
	echo "Attempting to clone $repo..."
	git clone $repo # 2> /dev/null

	#if we get a return code of 128 it means we can't clone the repo since the directory is empty
	if [ $? -eq 128 ]
	then
		echo "Updating $dir_name"

		cd $dir_name
		git checkout master
		git fetch
		git pull

		cd ..
	fi
done

echo ""
echo "Finished cloning $repo_counter Bower repos"
